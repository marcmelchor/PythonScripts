'''Get the name and lastname of a CSV File and save a new CSV File'''
'''Requires Python 3.X to work'''

import time
def headers():
	with open(r'headers.csv') as myfile:
		for line in myfile:
			header = line
	return header
	
def file_():
	x = 0
	with open(r'file_selected.csv') as myfile:
		for lines in myfile:
			file_[x] = lines
			x += 1
	return file_
	
file_ = file_()
header = headers()
print(header)
for file_ in lines:
	print(lines)
time.sleep(5)